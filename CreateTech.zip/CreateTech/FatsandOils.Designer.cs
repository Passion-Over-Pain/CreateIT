﻿namespace CreateTech
{
    partial class FatsandOils
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FatsandOils));
            this.pnlBackground = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.pnlOliveOil = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.pnlCoconutOil = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.lblCanolaOil = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblFatsandOils = new System.Windows.Forms.Label();
            this.backbtnicon = new System.Windows.Forms.PictureBox();
            this.profilepic = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.lbltime = new System.Windows.Forms.Label();
            this.pnlBackground.SuspendLayout();
            this.panel9.SuspendLayout();
            this.pnlOliveOil.SuspendLayout();
            this.pnlCoconutOil.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.backbtnicon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.profilepic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlBackground
            // 
            this.pnlBackground.BackColor = System.Drawing.Color.Black;
            this.pnlBackground.Controls.Add(this.lbltime);
            this.pnlBackground.Controls.Add(this.panel9);
            this.pnlBackground.Controls.Add(this.pnlOliveOil);
            this.pnlBackground.Controls.Add(this.pnlCoconutOil);
            this.pnlBackground.Controls.Add(this.panel6);
            this.pnlBackground.Controls.Add(this.panel5);
            this.pnlBackground.Controls.Add(this.panel1);
            this.pnlBackground.Controls.Add(this.pictureBox2);
            this.pnlBackground.Cursor = System.Windows.Forms.Cursors.PanNW;
            this.pnlBackground.Location = new System.Drawing.Point(-5, -26);
            this.pnlBackground.Name = "pnlBackground";
            this.pnlBackground.Size = new System.Drawing.Size(349, 722);
            this.pnlBackground.TabIndex = 3;
            this.pnlBackground.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlBackground_MouseMove);
            // 
            // panel9
            // 
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel9.Controls.Add(this.label5);
            this.panel9.Location = new System.Drawing.Point(73, 547);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(200, 83);
            this.panel9.TabIndex = 22;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Black;
            this.label5.Font = new System.Drawing.Font("Sitka Text", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(54, 15);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 30);
            this.label5.TabIndex = 0;
            this.label5.Text = "Nuts";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlOliveOil
            // 
            this.pnlOliveOil.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlOliveOil.Controls.Add(this.label4);
            this.pnlOliveOil.Location = new System.Drawing.Point(73, 448);
            this.pnlOliveOil.Name = "pnlOliveOil";
            this.pnlOliveOil.Size = new System.Drawing.Size(200, 83);
            this.pnlOliveOil.TabIndex = 23;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Black;
            this.label4.Font = new System.Drawing.Font("Sitka Text", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(43, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 30);
            this.label4.TabIndex = 0;
            this.label4.Text = "Olive Oil";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlCoconutOil
            // 
            this.pnlCoconutOil.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlCoconutOil.Controls.Add(this.label3);
            this.pnlCoconutOil.Location = new System.Drawing.Point(73, 356);
            this.pnlCoconutOil.Name = "pnlCoconutOil";
            this.pnlCoconutOil.Size = new System.Drawing.Size(200, 69);
            this.pnlCoconutOil.TabIndex = 24;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Black;
            this.label3.Font = new System.Drawing.Font("Sitka Text", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(43, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(119, 28);
            this.label3.TabIndex = 0;
            this.label3.Text = "Coconut Oil";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel6.Controls.Add(this.lblCanolaOil);
            this.panel6.Location = new System.Drawing.Point(73, 254);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(200, 83);
            this.panel6.TabIndex = 25;
            // 
            // lblCanolaOil
            // 
            this.lblCanolaOil.AutoSize = true;
            this.lblCanolaOil.BackColor = System.Drawing.Color.Black;
            this.lblCanolaOil.Font = new System.Drawing.Font("Sitka Text", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCanolaOil.ForeColor = System.Drawing.Color.White;
            this.lblCanolaOil.Location = new System.Drawing.Point(43, 0);
            this.lblCanolaOil.Name = "lblCanolaOil";
            this.lblCanolaOil.Size = new System.Drawing.Size(117, 30);
            this.lblCanolaOil.TabIndex = 0;
            this.lblCanolaOil.Text = "Canola Oil";
            this.lblCanolaOil.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel5.Controls.Add(this.label7);
            this.panel5.Location = new System.Drawing.Point(73, 154);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(200, 83);
            this.panel5.TabIndex = 20;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Black;
            this.label7.Font = new System.Drawing.Font("Sitka Text", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(54, 13);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 30);
            this.label7.TabIndex = 0;
            this.label7.Text = "Bread";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.backbtnicon);
            this.panel1.Controls.Add(this.profilepic);
            this.panel1.Controls.Add(this.lblFatsandOils);
            this.panel1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.panel1.Location = new System.Drawing.Point(8, 74);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(338, 53);
            this.panel1.TabIndex = 19;
            // 
            // lblFatsandOils
            // 
            this.lblFatsandOils.AutoSize = true;
            this.lblFatsandOils.BackColor = System.Drawing.Color.Black;
            this.lblFatsandOils.Font = new System.Drawing.Font("Sitka Text", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFatsandOils.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblFatsandOils.Location = new System.Drawing.Point(89, 8);
            this.lblFatsandOils.Name = "lblFatsandOils";
            this.lblFatsandOils.Size = new System.Drawing.Size(145, 30);
            this.lblFatsandOils.TabIndex = 1;
            this.lblFatsandOils.Text = "Fats and Oils";
            this.lblFatsandOils.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // backbtnicon
            // 
            this.backbtnicon.Image = ((System.Drawing.Image)(resources.GetObject("backbtnicon.Image")));
            this.backbtnicon.Location = new System.Drawing.Point(0, 3);
            this.backbtnicon.Name = "backbtnicon";
            this.backbtnicon.Size = new System.Drawing.Size(40, 47);
            this.backbtnicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.backbtnicon.TabIndex = 12;
            this.backbtnicon.TabStop = false;
            this.backbtnicon.Click += new System.EventHandler(this.backbtnicon_Click);
            // 
            // profilepic
            // 
            this.profilepic.BackgroundImage = global::CreateTech.Properties.Resources.circle;
            this.profilepic.Image = global::CreateTech.Properties.Resources.Profile_Icon;
            this.profilepic.Location = new System.Drawing.Point(288, 0);
            this.profilepic.Name = "profilepic";
            this.profilepic.Size = new System.Drawing.Size(50, 45);
            this.profilepic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.profilepic.TabIndex = 11;
            this.profilepic.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(-49, 1);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(446, 86);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 11;
            this.pictureBox2.TabStop = false;
            // 
            // lbltime
            // 
            this.lbltime.AutoSize = true;
            this.lbltime.BackColor = System.Drawing.Color.Black;
            this.lbltime.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltime.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbltime.Location = new System.Drawing.Point(123, 26);
            this.lbltime.Name = "lbltime";
            this.lbltime.Size = new System.Drawing.Size(79, 31);
            this.lbltime.TabIndex = 20;
            this.lbltime.Text = "12:00";
            // 
            // FatsandOils
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(339, 670);
            this.Controls.Add(this.pnlBackground);
            this.Name = "FatsandOils";
            this.Text = "FatsandOils";
            this.pnlBackground.ResumeLayout(false);
            this.pnlBackground.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.pnlOliveOil.ResumeLayout(false);
            this.pnlOliveOil.PerformLayout();
            this.pnlCoconutOil.ResumeLayout(false);
            this.pnlCoconutOil.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.backbtnicon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.profilepic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlBackground;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel pnlOliveOil;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel pnlCoconutOil;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label lblCanolaOil;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox backbtnicon;
        private System.Windows.Forms.PictureBox profilepic;
        private System.Windows.Forms.Label lblFatsandOils;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label lbltime;
    }
}