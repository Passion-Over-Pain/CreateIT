﻿namespace CreateTech
{
    partial class Dairy_Products
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dairy_Products));
            this.pnlBackground = new System.Windows.Forms.Panel();
            this.pnlYoghurt = new System.Windows.Forms.Panel();
            this.lblYoghurt = new System.Windows.Forms.Label();
            this.pnlIceCream = new System.Windows.Forms.Panel();
            this.lblIceCream = new System.Windows.Forms.Label();
            this.pnlMilk = new System.Windows.Forms.Panel();
            this.lblMilk = new System.Windows.Forms.Label();
            this.pnlCheese = new System.Windows.Forms.Panel();
            this.lblCheese = new System.Windows.Forms.Label();
            this.pnlButter = new System.Windows.Forms.Panel();
            this.lblButter = new System.Windows.Forms.Label();
            this.pnlTitle = new System.Windows.Forms.Panel();
            this.lbldairy = new System.Windows.Forms.Label();
            this.backbtnicon = new System.Windows.Forms.PictureBox();
            this.profilepic = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.lbltime = new System.Windows.Forms.Label();
            this.pnlBackground.SuspendLayout();
            this.pnlYoghurt.SuspendLayout();
            this.pnlIceCream.SuspendLayout();
            this.pnlMilk.SuspendLayout();
            this.pnlCheese.SuspendLayout();
            this.pnlButter.SuspendLayout();
            this.pnlTitle.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.backbtnicon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.profilepic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlBackground
            // 
            this.pnlBackground.BackColor = System.Drawing.Color.Black;
            this.pnlBackground.Controls.Add(this.lbltime);
            this.pnlBackground.Controls.Add(this.pnlYoghurt);
            this.pnlBackground.Controls.Add(this.pnlIceCream);
            this.pnlBackground.Controls.Add(this.pnlMilk);
            this.pnlBackground.Controls.Add(this.pnlCheese);
            this.pnlBackground.Controls.Add(this.pnlButter);
            this.pnlBackground.Controls.Add(this.pnlTitle);
            this.pnlBackground.Controls.Add(this.pictureBox2);
            this.pnlBackground.Cursor = System.Windows.Forms.Cursors.PanNW;
            this.pnlBackground.Location = new System.Drawing.Point(-5, -26);
            this.pnlBackground.Name = "pnlBackground";
            this.pnlBackground.Size = new System.Drawing.Size(349, 722);
            this.pnlBackground.TabIndex = 3;
            this.pnlBackground.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlBackground_MouseMove);
            // 
            // pnlYoghurt
            // 
            this.pnlYoghurt.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlYoghurt.Controls.Add(this.lblYoghurt);
            this.pnlYoghurt.Location = new System.Drawing.Point(73, 547);
            this.pnlYoghurt.Name = "pnlYoghurt";
            this.pnlYoghurt.Size = new System.Drawing.Size(200, 83);
            this.pnlYoghurt.TabIndex = 22;
            // 
            // lblYoghurt
            // 
            this.lblYoghurt.AutoSize = true;
            this.lblYoghurt.BackColor = System.Drawing.Color.Black;
            this.lblYoghurt.Font = new System.Drawing.Font("Sitka Text", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblYoghurt.ForeColor = System.Drawing.Color.White;
            this.lblYoghurt.Location = new System.Drawing.Point(47, 10);
            this.lblYoghurt.Name = "lblYoghurt";
            this.lblYoghurt.Size = new System.Drawing.Size(95, 30);
            this.lblYoghurt.TabIndex = 0;
            this.lblYoghurt.Text = "Yoghurt";
            this.lblYoghurt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlIceCream
            // 
            this.pnlIceCream.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlIceCream.Controls.Add(this.lblIceCream);
            this.pnlIceCream.Location = new System.Drawing.Point(73, 448);
            this.pnlIceCream.Name = "pnlIceCream";
            this.pnlIceCream.Size = new System.Drawing.Size(200, 83);
            this.pnlIceCream.TabIndex = 23;
            // 
            // lblIceCream
            // 
            this.lblIceCream.AutoSize = true;
            this.lblIceCream.BackColor = System.Drawing.Color.Black;
            this.lblIceCream.Font = new System.Drawing.Font("Sitka Text", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIceCream.ForeColor = System.Drawing.Color.White;
            this.lblIceCream.Location = new System.Drawing.Point(39, 9);
            this.lblIceCream.Name = "lblIceCream";
            this.lblIceCream.Size = new System.Drawing.Size(111, 30);
            this.lblIceCream.TabIndex = 0;
            this.lblIceCream.Text = "Ice cream";
            this.lblIceCream.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlMilk
            // 
            this.pnlMilk.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlMilk.Controls.Add(this.lblMilk);
            this.pnlMilk.Location = new System.Drawing.Point(73, 356);
            this.pnlMilk.Name = "pnlMilk";
            this.pnlMilk.Size = new System.Drawing.Size(200, 69);
            this.pnlMilk.TabIndex = 24;
            // 
            // lblMilk
            // 
            this.lblMilk.AutoSize = true;
            this.lblMilk.BackColor = System.Drawing.Color.Black;
            this.lblMilk.Font = new System.Drawing.Font("Sitka Text", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMilk.ForeColor = System.Drawing.Color.White;
            this.lblMilk.Location = new System.Drawing.Point(68, 10);
            this.lblMilk.Name = "lblMilk";
            this.lblMilk.Size = new System.Drawing.Size(54, 28);
            this.lblMilk.TabIndex = 0;
            this.lblMilk.Text = "Milk";
            this.lblMilk.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlCheese
            // 
            this.pnlCheese.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlCheese.Controls.Add(this.lblCheese);
            this.pnlCheese.Location = new System.Drawing.Point(73, 254);
            this.pnlCheese.Name = "pnlCheese";
            this.pnlCheese.Size = new System.Drawing.Size(200, 83);
            this.pnlCheese.TabIndex = 25;
            // 
            // lblCheese
            // 
            this.lblCheese.AutoSize = true;
            this.lblCheese.BackColor = System.Drawing.Color.Black;
            this.lblCheese.Font = new System.Drawing.Font("Sitka Text", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCheese.ForeColor = System.Drawing.Color.White;
            this.lblCheese.Location = new System.Drawing.Point(54, 0);
            this.lblCheese.Name = "lblCheese";
            this.lblCheese.Size = new System.Drawing.Size(82, 30);
            this.lblCheese.TabIndex = 0;
            this.lblCheese.Text = "Cheese";
            this.lblCheese.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlButter
            // 
            this.pnlButter.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlButter.Controls.Add(this.lblButter);
            this.pnlButter.Location = new System.Drawing.Point(73, 154);
            this.pnlButter.Name = "pnlButter";
            this.pnlButter.Size = new System.Drawing.Size(200, 83);
            this.pnlButter.TabIndex = 20;
            // 
            // lblButter
            // 
            this.lblButter.AutoSize = true;
            this.lblButter.BackColor = System.Drawing.Color.Black;
            this.lblButter.Font = new System.Drawing.Font("Sitka Text", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblButter.ForeColor = System.Drawing.Color.White;
            this.lblButter.Location = new System.Drawing.Point(54, 13);
            this.lblButter.Name = "lblButter";
            this.lblButter.Size = new System.Drawing.Size(79, 30);
            this.lblButter.TabIndex = 0;
            this.lblButter.Text = "Butter";
            this.lblButter.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlTitle
            // 
            this.pnlTitle.BackColor = System.Drawing.Color.Black;
            this.pnlTitle.Controls.Add(this.backbtnicon);
            this.pnlTitle.Controls.Add(this.profilepic);
            this.pnlTitle.Controls.Add(this.lbldairy);
            this.pnlTitle.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.pnlTitle.Location = new System.Drawing.Point(8, 74);
            this.pnlTitle.Name = "pnlTitle";
            this.pnlTitle.Size = new System.Drawing.Size(338, 53);
            this.pnlTitle.TabIndex = 19;
            // 
            // lbldairy
            // 
            this.lbldairy.AutoSize = true;
            this.lbldairy.BackColor = System.Drawing.Color.Black;
            this.lbldairy.Font = new System.Drawing.Font("Sitka Text", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldairy.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbldairy.Location = new System.Drawing.Point(89, 8);
            this.lbldairy.Name = "lbldairy";
            this.lbldairy.Size = new System.Drawing.Size(166, 30);
            this.lbldairy.TabIndex = 1;
            this.lbldairy.Text = "Dairy Products";
            this.lbldairy.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // backbtnicon
            // 
            this.backbtnicon.Image = ((System.Drawing.Image)(resources.GetObject("backbtnicon.Image")));
            this.backbtnicon.Location = new System.Drawing.Point(0, 3);
            this.backbtnicon.Name = "backbtnicon";
            this.backbtnicon.Size = new System.Drawing.Size(40, 47);
            this.backbtnicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.backbtnicon.TabIndex = 12;
            this.backbtnicon.TabStop = false;
            this.backbtnicon.Click += new System.EventHandler(this.backbtnicon_Click);
            // 
            // profilepic
            // 
            this.profilepic.BackgroundImage = global::CreateTech.Properties.Resources.circle;
            this.profilepic.Image = global::CreateTech.Properties.Resources.Profile_Icon;
            this.profilepic.Location = new System.Drawing.Point(288, 0);
            this.profilepic.Name = "profilepic";
            this.profilepic.Size = new System.Drawing.Size(50, 45);
            this.profilepic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.profilepic.TabIndex = 11;
            this.profilepic.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(-53, 1);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(446, 86);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 11;
            this.pictureBox2.TabStop = false;
            // 
            // lbltime
            // 
            this.lbltime.AutoSize = true;
            this.lbltime.BackColor = System.Drawing.Color.Black;
            this.lbltime.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltime.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbltime.Location = new System.Drawing.Point(121, 21);
            this.lbltime.Name = "lbltime";
            this.lbltime.Size = new System.Drawing.Size(79, 31);
            this.lbltime.TabIndex = 20;
            this.lbltime.Text = "12:00";
            // 
            // Dairy_Products
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(339, 670);
            this.Controls.Add(this.pnlBackground);
            this.Name = "Dairy_Products";
            this.Text = "3";
            this.pnlBackground.ResumeLayout(false);
            this.pnlBackground.PerformLayout();
            this.pnlYoghurt.ResumeLayout(false);
            this.pnlYoghurt.PerformLayout();
            this.pnlIceCream.ResumeLayout(false);
            this.pnlIceCream.PerformLayout();
            this.pnlMilk.ResumeLayout(false);
            this.pnlMilk.PerformLayout();
            this.pnlCheese.ResumeLayout(false);
            this.pnlCheese.PerformLayout();
            this.pnlButter.ResumeLayout(false);
            this.pnlButter.PerformLayout();
            this.pnlTitle.ResumeLayout(false);
            this.pnlTitle.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.backbtnicon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.profilepic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlBackground;
        private System.Windows.Forms.Panel pnlYoghurt;
        private System.Windows.Forms.Label lblYoghurt;
        private System.Windows.Forms.Panel pnlIceCream;
        private System.Windows.Forms.Label lblIceCream;
        private System.Windows.Forms.Panel pnlMilk;
        private System.Windows.Forms.Label lblMilk;
        private System.Windows.Forms.Panel pnlCheese;
        private System.Windows.Forms.Label lblCheese;
        private System.Windows.Forms.Panel pnlButter;
        private System.Windows.Forms.Label lblButter;
        private System.Windows.Forms.Panel pnlTitle;
        private System.Windows.Forms.PictureBox backbtnicon;
        private System.Windows.Forms.PictureBox profilepic;
        private System.Windows.Forms.Label lbldairy;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label lbltime;
    }
}