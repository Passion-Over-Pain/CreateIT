﻿namespace CreateTech
{
    partial class Protien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Protien));
            this.pnlBackground = new System.Windows.Forms.Panel();
            this.pnlLamb = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.pnlBeef = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.pnlEggs = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.pnlChicken = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.lblBeans = new System.Windows.Forms.Panel();
            this.lblEggs = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblProtein = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.backbtnicon = new System.Windows.Forms.PictureBox();
            this.profilepic = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.lbltime = new System.Windows.Forms.Label();
            this.pnlBackground.SuspendLayout();
            this.pnlLamb.SuspendLayout();
            this.pnlBeef.SuspendLayout();
            this.pnlEggs.SuspendLayout();
            this.pnlChicken.SuspendLayout();
            this.lblBeans.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.backbtnicon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.profilepic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlBackground
            // 
            this.pnlBackground.BackColor = System.Drawing.Color.Black;
            this.pnlBackground.Controls.Add(this.lbltime);
            this.pnlBackground.Controls.Add(this.pnlLamb);
            this.pnlBackground.Controls.Add(this.pnlBeef);
            this.pnlBackground.Controls.Add(this.pnlEggs);
            this.pnlBackground.Controls.Add(this.pnlChicken);
            this.pnlBackground.Controls.Add(this.lblBeans);
            this.pnlBackground.Controls.Add(this.panel1);
            this.pnlBackground.Controls.Add(this.pictureBox2);
            this.pnlBackground.Cursor = System.Windows.Forms.Cursors.PanNW;
            this.pnlBackground.Location = new System.Drawing.Point(-5, -26);
            this.pnlBackground.Name = "pnlBackground";
            this.pnlBackground.Size = new System.Drawing.Size(349, 722);
            this.pnlBackground.TabIndex = 3;
            this.pnlBackground.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlBackground_MouseMove);
            // 
            // pnlLamb
            // 
            this.pnlLamb.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlLamb.Controls.Add(this.label1);
            this.pnlLamb.Controls.Add(this.label5);
            this.pnlLamb.Location = new System.Drawing.Point(73, 547);
            this.pnlLamb.Name = "pnlLamb";
            this.pnlLamb.Size = new System.Drawing.Size(200, 83);
            this.pnlLamb.TabIndex = 22;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Black;
            this.label5.Font = new System.Drawing.Font("Sitka Text", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(54, 15);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 30);
            this.label5.TabIndex = 0;
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlBeef
            // 
            this.pnlBeef.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlBeef.Controls.Add(this.label4);
            this.pnlBeef.Location = new System.Drawing.Point(73, 448);
            this.pnlBeef.Name = "pnlBeef";
            this.pnlBeef.Size = new System.Drawing.Size(200, 83);
            this.pnlBeef.TabIndex = 23;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Black;
            this.label4.Font = new System.Drawing.Font("Sitka Text", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(41, 17);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(112, 30);
            this.label4.TabIndex = 0;
            this.label4.Text = "Lean Beef";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlEggs
            // 
            this.pnlEggs.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlEggs.Controls.Add(this.label3);
            this.pnlEggs.Location = new System.Drawing.Point(73, 356);
            this.pnlEggs.Name = "pnlEggs";
            this.pnlEggs.Size = new System.Drawing.Size(200, 69);
            this.pnlEggs.TabIndex = 24;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Black;
            this.label3.Font = new System.Drawing.Font("Sitka Text", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(58, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 28);
            this.label3.TabIndex = 0;
            this.label3.Text = "Eggs";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlChicken
            // 
            this.pnlChicken.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlChicken.Controls.Add(this.label2);
            this.pnlChicken.Location = new System.Drawing.Point(73, 254);
            this.pnlChicken.Name = "pnlChicken";
            this.pnlChicken.Size = new System.Drawing.Size(200, 83);
            this.pnlChicken.TabIndex = 25;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Black;
            this.label2.Font = new System.Drawing.Font("Sitka Text", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(58, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 30);
            this.label2.TabIndex = 0;
            this.label2.Text = "Chicken";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblBeans
            // 
            this.lblBeans.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblBeans.Controls.Add(this.lblEggs);
            this.lblBeans.Location = new System.Drawing.Point(73, 154);
            this.lblBeans.Name = "lblBeans";
            this.lblBeans.Size = new System.Drawing.Size(200, 83);
            this.lblBeans.TabIndex = 20;
            // 
            // lblEggs
            // 
            this.lblEggs.AutoSize = true;
            this.lblEggs.BackColor = System.Drawing.Color.Black;
            this.lblEggs.Font = new System.Drawing.Font("Sitka Text", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEggs.ForeColor = System.Drawing.Color.White;
            this.lblEggs.Location = new System.Drawing.Point(54, 13);
            this.lblEggs.Name = "lblEggs";
            this.lblEggs.Size = new System.Drawing.Size(73, 30);
            this.lblEggs.TabIndex = 0;
            this.lblEggs.Text = "Beans";
            this.lblEggs.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.backbtnicon);
            this.panel1.Controls.Add(this.profilepic);
            this.panel1.Controls.Add(this.lblProtein);
            this.panel1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.panel1.Location = new System.Drawing.Point(8, 74);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(338, 53);
            this.panel1.TabIndex = 19;
            // 
            // lblProtein
            // 
            this.lblProtein.AutoSize = true;
            this.lblProtein.BackColor = System.Drawing.Color.Black;
            this.lblProtein.Font = new System.Drawing.Font("Sitka Text", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProtein.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblProtein.Location = new System.Drawing.Point(121, 3);
            this.lblProtein.Name = "lblProtein";
            this.lblProtein.Size = new System.Drawing.Size(88, 30);
            this.lblProtein.TabIndex = 1;
            this.lblProtein.Text = "Protein";
            this.lblProtein.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Black;
            this.label1.Font = new System.Drawing.Font("Sitka Text", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(54, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 30);
            this.label1.TabIndex = 1;
            this.label1.Text = "Lamb";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // backbtnicon
            // 
            this.backbtnicon.Image = ((System.Drawing.Image)(resources.GetObject("backbtnicon.Image")));
            this.backbtnicon.Location = new System.Drawing.Point(0, 3);
            this.backbtnicon.Name = "backbtnicon";
            this.backbtnicon.Size = new System.Drawing.Size(40, 47);
            this.backbtnicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.backbtnicon.TabIndex = 12;
            this.backbtnicon.TabStop = false;
            this.backbtnicon.Click += new System.EventHandler(this.backbtnicon_Click);
            // 
            // profilepic
            // 
            this.profilepic.BackgroundImage = global::CreateTech.Properties.Resources.circle;
            this.profilepic.Image = global::CreateTech.Properties.Resources.Profile_Icon;
            this.profilepic.Location = new System.Drawing.Point(288, 0);
            this.profilepic.Name = "profilepic";
            this.profilepic.Size = new System.Drawing.Size(50, 45);
            this.profilepic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.profilepic.TabIndex = 11;
            this.profilepic.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(-51, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(446, 86);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 11;
            this.pictureBox2.TabStop = false;
            // 
            // lbltime
            // 
            this.lbltime.AutoSize = true;
            this.lbltime.BackColor = System.Drawing.Color.Black;
            this.lbltime.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltime.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbltime.Location = new System.Drawing.Point(128, 24);
            this.lbltime.Name = "lbltime";
            this.lbltime.Size = new System.Drawing.Size(79, 31);
            this.lbltime.TabIndex = 26;
            this.lbltime.Text = "12:00";
            // 
            // Protien
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(339, 670);
            this.Controls.Add(this.pnlBackground);
            this.Name = "Protien";
            this.Text = "Protien";
            this.pnlBackground.ResumeLayout(false);
            this.pnlBackground.PerformLayout();
            this.pnlLamb.ResumeLayout(false);
            this.pnlLamb.PerformLayout();
            this.pnlBeef.ResumeLayout(false);
            this.pnlBeef.PerformLayout();
            this.pnlEggs.ResumeLayout(false);
            this.pnlEggs.PerformLayout();
            this.pnlChicken.ResumeLayout(false);
            this.pnlChicken.PerformLayout();
            this.lblBeans.ResumeLayout(false);
            this.lblBeans.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.backbtnicon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.profilepic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlBackground;
        private System.Windows.Forms.Panel pnlLamb;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel pnlBeef;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel pnlEggs;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel pnlChicken;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel lblBeans;
        private System.Windows.Forms.Label lblEggs;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox backbtnicon;
        private System.Windows.Forms.PictureBox profilepic;
        private System.Windows.Forms.Label lblProtein;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbltime;
    }
}